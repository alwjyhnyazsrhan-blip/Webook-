﻿from sqlalchemy import Column, BigInteger, Integer, String, DateTime, ForeignKey, JSON, Boolean
from database.models.base import Base
from datetime import datetime, timezone
import enum


class TaskStatus(enum.Enum):
    CREATED       = "CREATED"
    AUTH_REQUIRED = "AUTH_REQUIRED"
    QUEUED        = "QUEUED"
    PROCESSING    = "PROCESSING"
    SEARCHING     = "SEARCHING"
    RUNNING       = "RUNNING"
    HOLDING       = "HOLDING"
    RESERVED      = "RESERVED"
    SUCCESS       = "SUCCESS"
    COMPLETED     = "COMPLETED"
    FAILED        = "FAILED"
    RETRYING      = "RETRYING"
    EXPIRED       = "EXPIRED"
    CANCELLED     = "CANCELLED"


# Status contract helpers
VALID_TASK_STATUSES: frozenset = frozenset(s.value for s in TaskStatus)

TERMINAL_TASK_STATUSES: frozenset = frozenset({
    TaskStatus.COMPLETED.value, TaskStatus.FAILED.value,
    TaskStatus.CANCELLED.value, TaskStatus.EXPIRED.value,
    TaskStatus.SUCCESS.value,
})

ACTIVE_TASK_STATUSES: frozenset = frozenset({
    TaskStatus.QUEUED.value, TaskStatus.SEARCHING.value,
    TaskStatus.RETRYING.value, TaskStatus.PROCESSING.value,
    TaskStatus.RUNNING.value, TaskStatus.HOLDING.value,
})


def normalize_status(raw: str) -> str:
    """
    Coerce any status string to canonical UPPERCASE form.
    Raises ValueError for unknown statuses.
    Single gate for all status normalization â€” never write raw lowercase to task.status.
    """
    if raw is None:
        raise ValueError("task status is None")
    normalized = raw.strip().upper()
    if normalized not in VALID_TASK_STATUSES:
        raise ValueError(
            f"Unknown task status: '{raw}' (normalized='{normalized}'). "
            f"Valid: {sorted(VALID_TASK_STATUSES)}"
        )
    return normalized


class ReservationTask(Base):
    __tablename__ = "reservation_tasks"

    id = Column(Integer, primary_key=True)
    user_id = Column(BigInteger, index=True)
    account_id = Column(Integer, ForeignKey("auth_sessions.id"), nullable=True)

    # Target Data (Immutable once queued)
    event_slug = Column(String, nullable=False)
    event_id = Column(String, nullable=True)
    category = Column(String, nullable=True) # Human-readable category/ticket label. Legacy rows may still hold a raw ticket id.
    timeslot_id = Column(String, nullable=True)
    team_id = Column(String, nullable=True)
    zone = Column(String, nullable=True) # E.g. "Block A"
    seat_count = Column(Integer, default=1)

    # State Machine & Orchestration
    status = Column(String, default=TaskStatus.CREATED.value, index=True)
    worker_id = Column(String, nullable=True)   # UUID of the worker owning the task
    last_heartbeat = Column(DateTime(timezone=True), nullable=True)  # For failover detection

    # Hold & Success Data
    hold_token = Column(String, nullable=True)
    reservation_id = Column(String, nullable=True)
    hold_expires_at = Column(DateTime(timezone=True), nullable=True)

    # Resilience & Telemetry
    retry_count = Column(Integer, default=0)
    error_message = Column(String, nullable=True)
    # Sniper mode: skip all human simulation delays for maximum speed
    sniper_mode = Column(Boolean, default=False)
    trace_id = Column(String, nullable=True)  # Links task execution to origin UI trace
    root_trace_id = Column(String, nullable=True)
    depth = Column(Integer, default=0)

    execution_logs = Column(JSON, default=list)  # Full trace [timestamp, state, msg]

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )

    def get_selection_context(self) -> dict:
        logs = self.execution_logs or []
        if not isinstance(logs, list):
            return {}
        for entry in reversed(logs):
            if isinstance(entry, dict) and isinstance(entry.get("selection_context"), dict):
                return entry["selection_context"]
        return {}

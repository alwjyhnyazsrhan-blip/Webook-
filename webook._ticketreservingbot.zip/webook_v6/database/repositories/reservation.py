﻿from sqlalchemy import select
from database.repositories.base import BaseRepository
from database.models.reservation import ReservationTask, TaskStatus

class ReservationRepository(BaseRepository[ReservationTask]):
    def __init__(self, session):
        super().__init__(ReservationTask, session)

    async def get_active_tasks(self):
        """
        Fetches tasks that are NOT in a final state (Success/Failed/Cancelled).
        Evidence: State-aware DB Query.
        """
        final_states = [TaskStatus.RESERVED.value, TaskStatus.FAILED.value, TaskStatus.CANCELLED.value]
        stmt = select(self.model).where(self.model.status.notin_(final_states))
        
        result = await self.session.execute(stmt)
        return result.scalars().all()

    async def get_all_tasks(self, limit=20):
        """Fetches history of tasks for the dashboard."""
        stmt = select(self.model).order_by(self.model.created_at.desc()).limit(limit)
        result = await self.session.execute(stmt)
        return result.scalars().all()


import sys

with open("modules/webook/client.py", "r", encoding="utf-8") as f:
    content = f.read()

start_marker = 'async def checkout_seated(self, slug: str, seats: list'
end_marker = '    async def release_reservation(self, slug: str,'

if start_marker not in content or end_marker not in content:
    print("Markers not found")
    sys.exit(1)

before = content.split(start_marker)[0]
after = end_marker + content.split(end_marker)[1]

new_method = '''async def checkout_seated(
        self, slug: str, seats: list, detail: dict = None,
        hold_token: str = None, event_id: str = None,
        lang: str = "ar", payment_method: str = "credit_card",
        time_slot_id: str = None, captcha_token: str = None,
        seats_io: dict = None, promo_code: str = None,
    ) -> dict:
        """
        Event Seat Checkout - OFFICIAL API SPEC section 3.2
        POST /event-detail/{slug}/event-seat/checkout

        Required fields:
          selectedSeats*: [{ id*, label*, categoryKey* (number), chart: { holdToken } }]
          holdToken:      str - from /hold-token endpoint
          payment_method*: credit_card | apple_pay | stc_pay | mada
          lang*:          en | ar | fr
          redirect*:      str - success redirect URL
          redirect_failed*: str - failure redirect URL

        Optional fields:
          event_id:       str
          booking_source: str
          promo_code:     str
        """
        import json
        self._logger = __import__('logging').getLogger('webook')
        self._logger.info(
            f"[SEATED_CHECKOUT_PREP] slug={slug} event_id={event_id} "
            f"seats_count={len(seats) if seats else 0} hold_token_present={bool(hold_token)}"
        )

        # Format seats per spec 3.2
        seats_list = []
        for s in (seats or []):
            seat_obj = {
                "id": str(s.get("id", "")),
                "label": str(s.get("label", s.get("id", ""))),
                "categoryKey": int(s.get("categoryKey", 0)),
            }
            if hold_token:
                seat_obj["chart"] = {"holdToken": hold_token}
            elif s.get("chart"):
                seat_obj["chart"] = s["chart"]
            seats_list.append(seat_obj)

        _EVENT_PAYMENT_METHODS = {"credit_card", "apple_pay", "stc_pay", "mada"}
        if payment_method not in _EVENT_PAYMENT_METHODS:
            payment_method = "credit_card"

        payload = {
            "selectedSeats": seats_list,
            "holdToken": hold_token or "",
            "payment_method": payment_method,
            "lang": lang,
            "redirect": f"https://webook.com/{lang}/payment-success",
            "redirect_failed": f"https://webook.com/{lang}/payment-failed",
        }

        if event_id:
            payload["event_id"] = event_id
        if promo_code:
            payload["promo_code"] = promo_code
        if captcha_token:
            payload["turnstile"] = captcha_token

        url = f"{self.BASE_URL}/event-detail/{slug}/event-seat/checkout"

        try:
            from core.logging.logger import logger
        except ImportError:
            logger = self._logger

        logger.info(f"[SEATED_CHECKOUT] POST {url}")
        logger.info(f"[SEATED_CHECKOUT] payload={json.dumps(payload, ensure_ascii=False, default=str)[:500]}")

        try:
            resp = await self._request("POST", url, authenticated=True, json=payload)
            logger.info(f"[SEATED_CHECKOUT_RESP] status={resp.status_code} body={resp.text[:500]}")
            data = resp.json()
            if isinstance(data, dict):
                data["_http_status"] = resp.status_code
            return data
        except Exception as e:
            logger.error(f"[SEATED_CHECKOUT_ERR] {e.__class__.__name__}: {e}")
            return {"status": "error", "message": str(e), "_http_status": 500}

'''

with open("modules/webook/client.py", "w", encoding="utf-8") as f:
    f.write(before + new_method + after)

print("checkout_seated successfully replaced.")

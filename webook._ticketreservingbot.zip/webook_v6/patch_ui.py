import sys

with open("apps/bot/handlers.py", "r", encoding="utf-8") as f:
    content = f.read()

start_marker = '# ── Smart metadata display: only show fields that have real data ──'
end_marker = '    logger.info(f"[DETAIL_RENDER_BEGIN] slug={slug}'

if start_marker not in content or end_marker not in content:
    print("Markers not found")
    sys.exit(1)

before = content.split(start_marker)[0]
after = end_marker + content.split(end_marker)[1]

new_ui = '''# ── Redesigned Event Card Layout ──
    title_str = clean_html(fields['title'])
    
    text = f"🏆 <b>{title_str}</b>\\n"
    if len(team_options) >= 2:
        t1 = clean_html(team_options[0]['name'])
        t2 = clean_html(team_options[1]['name'])
        text += f"<b>{t1} × {t2}</b>\\n\\n"
    else:
        text += "\\n"
        
    if fields['venue']:
        text += f"📍 {clean_html(fields['venue'])}\\n"
    if fields['date_str'] and fields['date_str'] not in ('غير محدد', 'N/A', ''):
        text += f"📅 <code>{fields['date_str']}</code>\\n"
        
    text += "\\n━━━━━━━━━━\\n\\n"
    
    has_available = False
    if tickets:
        text += f"🎫 <b>التذاكر المتاحة ({len(tickets)}):</b>\\n"
        for t in tickets[:8]:
            t_name = clean_html(t.get("title") or t.get("name") or "تذكرة")
            price_val = t.get("price") or t.get("base_price") or 0
            t_price = clean_html(format_price_sar(price_val))
            is_available = ticket_has_available_inventory(t)
            if is_available: has_available = True
            avail_icon = "🟢" if is_available else "🔴"
            text += f"{avail_icon} {t_name} — {t_price} SAR\\n"
    else:
        text += "🎫 <b>التذاكر:</b> لم يتم العثور على تذاكر\\n"
        
    text += "\\n🔄 آخر تحديث: الآن\\n"
    if has_available:
        text += "🟢 البيع مفتوح\\n"
    elif tickets:
        text += "🔴 مغلق / نفذت التذاكر\\n"
    else:
        text += "🟡 بانتظار الطرح\\n"
        
    text += "\\n━━━━━━━━━━\\n"

    if fields["partial"] or hydration_state in ("empty", "timeout", "failed"):
        missing = []
        if not fields['venue']: missing.append("المكان")
        if not fields['date_str'] or fields['date_str'] in ('غير محدد', 'N/A', ''): missing.append("الموعد")
        if missing:
            text += f"\\n⚠️ <i>بيانات غير متوفرة: {', '.join(missing)}</i>\\n<i>اضغط تحديث لجلب البيانات.</i>\\n"

    event_ref = event.id if event else slug
    
    # ── VALIDATION GATE: Compute data health before rendering actions ──
    has_venue = bool(fields['venue'] and fields['venue'] not in ('غير متوفر', 'N/A', ''))
    has_date = bool(fields['date_str'] and fields['date_str'] not in ('غير محدد', 'N/A', ''))
    has_tickets = bool(tickets)
    data_complete = has_venue or has_date  # At least one anchor of trust
    is_partial = fields.get("partial") or hydration_state in ("empty", "timeout", "failed")
    
    builder = InlineKeyboardBuilder()
    
    if data_complete:
        builder.row(types.InlineKeyboardButton(text="🎟 احجز الآن", callback_data=f"b_ev:{event_ref}"))
        builder.row(types.InlineKeyboardButton(text="⚡ حجز سريع", callback_data=f"s_bk:{event_ref}"))
    elif is_partial and has_tickets:
        builder.row(types.InlineKeyboardButton(text="🎟 احجز الآن", callback_data=f"b_ev:{event_ref}"))
    else:
        text += "\\n⛔ <b>الحجز غير متاح حالياً</b>\\n"
    
    if has_venue:
        builder.row(
            types.InlineKeyboardButton(text="🗺 عرض المخطط", callback_data=f"v_ch:{event_ref}"),
            types.InlineKeyboardButton(text="📡 تتبع التذاكر", callback_data=f"s_ad:{event_ref}")
        )
    else:
        builder.row(
            types.InlineKeyboardButton(text="📡 تتبع التذاكر", callback_data=f"s_ad:{event_ref}")
        )
    
    builder.row(
        types.InlineKeyboardButton(text="🔄 تحديث", callback_data=f"e_det:{event_ref}"),
        types.InlineKeyboardButton(text="↩️ عودة", callback_data="booking_start")
    )

'''

with open("apps/bot/handlers.py", "w", encoding="utf-8") as f:
    f.write(before + new_ui + after)

print("UI successfully replaced.")

﻿# Ghost Monitor module

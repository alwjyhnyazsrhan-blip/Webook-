import asyncio
import html
import re
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from database.models.discovery import LiveEvent, Genre
from modules.webook.client import WebookApiClient
from core.logging.logger import logger


GHOST_SCAN_INTERVAL = 120

_MOJIBAKE_MARKERS = ("Ã", "Â", "â", "ï", "")


def _repair_mojibake_text(text: str) -> str:
    if not isinstance(text, str) or not any(marker in text for marker in _MOJIBAKE_MARKERS):
        return text

    candidates = [text]
    for source_encoding in ("latin1", "cp1252"):
        try:
            candidates.append(text.encode(source_encoding).decode("utf-8"))
        except Exception:
            continue

    def score(value: str) -> tuple[int, int, int]:
        suspicious = sum(value.count(marker) for marker in _MOJIBAKE_MARKERS)
        arabic = sum(1 for char in value if "\u0600" <= char <= "\u06ff")
        replacement_chars = value.count("")
        return (suspicious + replacement_chars, -arabic, len(value))

    return min(candidates, key=score)


def _markdownish_to_html(text: str) -> str:
    if not isinstance(text, str):
        return text

    text = re.sub(
        r"\[([^\]]+)\]\((https?://[^)]+)\)",
        lambda match: f'<a href="{html.escape(match.group(2), quote=True)}">{match.group(1)}</a>',
        text,
    )
    text = re.sub(r"`([^`]+)`", lambda match: f"<code>{html.escape(match.group(1))}</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", lambda match: f"<b>{match.group(1)}</b>", text)
    text = re.sub(r"\*([^*\n]+)\*", lambda match: f"<i>{match.group(1)}</i>", text)
    return text


def _normalize_telegram_text(text: str) -> str:
    text = _repair_mojibake_text(str(text or ""))
    if any(token in text for token in ("**", "*", "`", "](")):
        text = _markdownish_to_html(text)
    return text

class GhostMonitor:
    """
    THE GHOST MONITOR - Silent Backend Watcher.

    Continuously scans Webook's backend for:
    1. New events that appear before public listing
    2. Ticket availability changes (sold out / available)
    3. Price changes
    4. Date/venue changes

    Generates notification dicts for the Telegram notification engine.
    """

    def __init__(self, db: AsyncSession):
        self.db = db
        self.api = WebookApiClient()
        self._known_slugs = set()
        self._known_prices = {}

    async def initialize(self):
        """Load known state from DB."""
        stmt = select(LiveEvent.slug, LiveEvent.min_price)
        result = await self.db.execute(stmt)
        for slug, price in result:
            self._known_slugs.add(slug)
            self._known_prices[slug] = price

    async def scan_once(self):
        """Execute a single scan iteration. Called externally by ghost_monitor_loop with a fresh session per call."""
        await self.initialize()
        try:
            changes = await self._scan_all_orgs()
            if changes:
                logger.info(f"GhostMonitor: Detected {len(changes)} changes")
                for change in changes:
                    await self._process_change(change)
            self._prune_known_cache()
        except Exception as e:
            logger.error(f"GhostMonitor: Scan failed: {e}")

    async def run(self):
        """Main ghost monitoring loop."""
        logger.info("GhostMonitor: Silent backend watcher STARTED")
        await self.initialize()

        while True:
            try:
                changes = await self._scan_all_orgs()
                if changes:
                    logger.info(f"GhostMonitor: Detected {len(changes)} changes")
                    for change in changes:
                        await self._process_change(change)
                
                self._prune_known_cache()
                
            except Exception as e:
                logger.error(f"GhostMonitor: Scan failed: {e}")

            await asyncio.sleep(GHOST_SCAN_INTERVAL)

    def _prune_known_cache(self):
        """Prevents memory leak by capping known event tracking."""
        MAX_CACHE = 5000
        if len(self._known_slugs) > MAX_CACHE:
            logger.info(f"GhostMonitor: Pruning cache (Size: {len(self._known_slugs)})")
            self._known_slugs = set(list(self._known_slugs)[-2000:])
            new_prices = {}
            for s in self._known_slugs:
                if s in self._known_prices:
                    new_prices[s] = self._known_prices[s]
            self._known_prices = new_prices

    async def _scan_all_orgs(self) -> list:
        """Scan all organizations for changes."""
        changes = []

        try:
            org_page = 1
            while True:
                org_res = await self.api.get_organizations(page=org_page)
                orgs = org_res.get("data", {}).get("data", [])
                if not orgs: break
                
                for org in orgs:
                    org_slug = org.get("slug")
                    if not org_slug: continue
                    
                    try:
                        result = await self.api.get_events_by_organization(
                            org_slug, lang="ar", per_page=50
                        )
                        events = result.get("events", [])
                        
                        for ev in events:
                            slug = ev.get("slug", "")
                            if not slug: continue
                            
                            if slug not in self._known_slugs:
                                raw_start = ev.get("start_date_time", "")
                                formatted_start = "\u063a\u064a\u0631 \u0645\u062d\u062f\u062f"
                                try:
                                    if isinstance(raw_start, (int, float)):
                                        formatted_start = datetime.fromtimestamp(raw_start, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
                                    elif isinstance(raw_start, str) and raw_start.isdigit():
                                        formatted_start = datetime.fromtimestamp(int(raw_start), tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
                                    elif isinstance(raw_start, str) and raw_start:
                                        formatted_start = raw_start[:16].replace("T", " ")
                                except Exception:
                                    formatted_start = str(raw_start)

                                raw_price = ev.get("min_price")
                                formatted_price = f"{raw_price} SAR" if raw_price else "\u063a\u064a\u0631 \u0645\u062d\u062f\u062f"

                                changes.append({
                                    "type": "NEW_EVENT",
                                    "slug": slug,
                                    "title": ev.get("title", slug),
                                    "org": org_slug,
                                    "venue": ev.get("venue", {}),
                                    "start": formatted_start,
                                    "min_price": formatted_price,
                                    "data": ev,
                                })
                                self._known_slugs.add(slug)

                            if slug in self._known_slugs:
                                stmt = select(LiveEvent).where(LiveEvent.slug == slug)
                                existing = (await self.db.execute(stmt)).scalar_one_or_none()
                                
                                if existing:
                                    new_date = ev.get("start_date_time")
                                    if existing.starts_at and new_date:
                                        dt_new = None
                                        if isinstance(new_date, (int, float)):
                                            dt_new = datetime.fromtimestamp(new_date, tz=timezone.utc)
                                        elif isinstance(new_date, str):
                                            dt_new = datetime.fromisoformat(new_date.replace("Z", "+00:00"))
                                        
                                        if dt_new and existing.starts_at != dt_new:
                                            changes.append({
                                                "type": "DATE_CHANGE",
                                                "slug": slug,
                                                "title": ev.get("title", slug),
                                                "old_val": existing.starts_at.strftime("%Y-%m-%d %H:%M"),
                                                "new_val": dt_new.strftime("%Y-%m-%d %H:%M")
                                            })
                                            existing.starts_at = dt_new

                                    new_venue = ev.get("venue", {}).get("name") if isinstance(ev.get("venue"), dict) else ev.get("venue")
                                    if existing.venue_name and new_venue and existing.venue_name != new_venue:
                                        changes.append({
                                            "type": "LOCATION_CHANGE",
                                            "slug": slug,
                                            "title": ev.get("title", slug),
                                            "old_val": existing.venue_name,
                                            "new_val": new_venue
                                        })
                                        existing.venue_name = new_venue

                                    new_status = ev.get("status", "").upper()
                                    if existing.status and new_status and existing.status != new_status:
                                        if new_status == "AVAILABLE": 
                                            changes.append({
                                                "type": "AVAILABILITY_ALERT",
                                                "slug": slug,
                                                "title": ev.get("title", slug),
                                                "old_val": existing.status,
                                                "new_val": new_status
                                            })
                                        existing.status = new_status
                                    
                                    await self.db.commit()

                            new_price = ev.get("min_price")
                            old_price = self._known_prices.get(slug)
                            if old_price and new_price and old_price != new_price:
                                changes.append({
                                    "type": "PRICE_CHANGE",
                                    "slug": slug,
                                    "title": ev.get("title", slug),
                                    "old_price": old_price,
                                    "new_price": new_price,
                                })
                            self._known_prices[slug] = new_price

                    except Exception as e:
                        logger.error(f"GhostMonitor: Sync loop error for {org_slug}: {e}")
                
                if len(orgs) < 100: break
                org_page += 1
                
        except Exception as e:
            logger.error(f"GhostMonitor: Org discovery failed: {e}")

        return changes

    async def _process_change(self, change: dict):
        """Store detected change for notification dispatch."""
        from apps.bot.main import bot
        from core.config.settings import settings
        change_type = change["type"]

        if change_type == "NEW_EVENT":
            logger.info(f"GhostMonitor: New event '{change['title']}' from {change['org']}")
            msg = (
                f"\U0001f52e <b>\u062a\u0646\u0628\u064a\u0647: \u0641\u0639\u0627\u0644\u064a\u0629 \u062c\u062f\u064a\u062f\u0629!</b>\n"
                f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
                f"\U0001f3ad <b>{change['title']}</b>\n"
                f"\U0001f3e2 \u0627\u0644\u0645\u0646\u0638\u0645\u0629: <code>{change['org']}</code>\n"
                f"\U0001f4b0 \u0627\u0644\u0633\u0639\u0631: <code>{change['min_price']}</code>\n"
                f"\U0001f552 \u0627\u0644\u0628\u062f\u0627\u064a\u0629: <code>{change['start']}</code>\n"
                f"\U0001f517 <a href=\"https://webook.com/ar/events/{change['slug']}\">\u0631\u0627\u0628\u0637 \u0627\u0644\u0641\u0639\u0627\u0644\u064a\u0629</a>\n"
                f"\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n"
                f"\u26a0\ufe0f <i>\u062a\u0646\u0628\u064a\u0647! \u062a\u0645 \u0627\u0643\u062a\u0634\u0627\u0641 \u0647\u0630\u0647 \u0627\u0644\u0641\u0639\u0627\u0644\u064a\u0629 \u062a\u0644\u0642\u0627\u0626\u064a\u0627\u064b</i>"
            )
            await self._broadcast(msg)
            await self._persist_new_event(change)

        elif change_type == "PRICE_CHANGE":
            msg = (
                f"\U0001f4b0 <b>\u062a\u0646\u0628\u064a\u0647: \u062a\u063a\u064a\u0631 \u0641\u064a \u0627\u0644\u0623\u0633\u0639\u0627\u0631!</b>\n"
                f"\U0001f3ad {change['title']}\n"
                f"\U0001f4c9 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0642\u062f\u064a\u0645: <code>{change['old_price']} SAR</code>\n"
                f"\U0001f4c8 \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u062c\u062f\u064a\u062f: <code>{change['new_price']} SAR</code>\n"
                f"\U0001f517 <a href=\"https://webook.com/ar/events/{change['slug']}\">\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644</a>"
            )
            await self._broadcast(msg)

        elif change_type == "DATE_CHANGE":
            msg = (
                f"\U0001f4c5 <b>\u062a\u0646\u0628\u064a\u0647: \u062a\u063a\u064a\u0631 \u0641\u064a \u0627\u0644\u0645\u0648\u0639\u062f!</b>\n"
                f"\U0001f3ad {change['title']}\n"
                f"\u274c \u0627\u0644\u0645\u0648\u0639\u062f \u0627\u0644\u0642\u062f\u064a\u0645: <code>{change['old_val']}</code>\n"
                f"\u2705 \u0627\u0644\u0645\u0648\u0639\u062f \u0627\u0644\u062c\u062f\u064a\u062f: <code>{change['new_val']}</code>\n"
                f"\U0001f517 <a href=\"https://webook.com/ar/events/{change['slug']}\">\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644</a>"
            )
            await self._broadcast(msg)

        elif change_type == "LOCATION_CHANGE":
            msg = (
                f"\U0001f4cd <b>\u062a\u0646\u0628\u064a\u0647: \u062a\u063a\u064a\u0631 \u0641\u064a \u0627\u0644\u0645\u0643\u0627\u0646!</b>\n"
                f"\U0001f3ad {change['title']}\n"
                f"\U0001f3db \u0627\u0644\u0645\u0643\u0627\u0646 \u0627\u0644\u062c\u062f\u064a\u062f: <code>{change['new_val']}</code>\n"
                f"\U0001f517 <a href=\"https://webook.com/ar/events/{change['slug']}\">\u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644</a>"
            )
            await self._broadcast(msg)

        elif change_type == "AVAILABILITY_ALERT":
            msg = (
                f"\U0001f7e2 <b>\u062a\u0646\u0628\u064a\u0647: \u062a\u0648\u0641\u0631 \u062a\u0630\u0627\u0643\u0631 \u0641\u062c\u0623\u0629!</b>\n"
                f"\U0001f3ad {change['title']}\n"
                f"\u0627\u0644\u062d\u0627\u0644\u0629: <code>{change['old_val']}</code> \u2794 <b>AVAILABLE</b> \U0001f525\n"
                f"\U0001f517 <a href=\"https://webook.com/ar/events/{change['slug']}\">\u0627\u062d\u062c\u0632 \u0627\u0644\u0622\u0646 \u0645\u062c\u0627\u0646\u0627!</a>"
            )
            await self._broadcast(msg)

    async def _broadcast(self, msg: str):
        """Send message to all admins and potentially subscribers."""
        from apps.bot.main import bot
        from core.config.settings import settings
        for admin_id in settings.admin_ids:
            try:
                await bot.send_message(admin_id, _normalize_telegram_text(msg), parse_mode="HTML")
            except: pass

    async def _persist_new_event(self, change: dict):
        """Helper to save new event to DB."""
        ev = change.get("data", {})
        slug = change["slug"]
        stmt = select(LiveEvent).where(LiveEvent.slug == slug)
        existing = (await self.db.execute(stmt)).scalar_one_or_none()
        if not existing:
            org_slug = change["org"]
            genre_stmt = select(Genre).where(Genre.slug == org_slug)
            genre = (await self.db.execute(genre_stmt)).scalar_one_or_none()
            genre_id = genre.id if genre else None
            new_event = LiveEvent(
                webook_id=str(ev.get("_id", "")),
                slug=slug,
                title_ar=change["title"],
                title_en=change["title"],
                genre_id=genre_id,
                status="GHOST",
                min_price=change.get("min_price"),
                metadata_json=ev,
            )
            self.db.add(new_event)
            await self.db.commit()

    async def get_pending_notifications(self) -> list:
        """Get ghost-detected events for notification dispatch."""
        stmt = select(LiveEvent).where(LiveEvent.status == "GHOST")
        result = await self.db.execute(stmt)
        return result.scalars().all()

    async def check_event_deep(self, slug: str) -> dict:
        """Deep scan a specific event for full availability."""
        detail = await self.api.get_event_detail(slug)
        tickets = await self.api.get_event_tickets(slug)
        resale = await self.api.get_resale_listing(slug)

        return {
            "detail": detail,
            "tickets": tickets,
            "resale": resale,
            "has_chart": bool(detail.get("chart_token") or detail.get("chartToken")),
            "ticket_count": len(tickets.get("data", [])) if isinstance(tickets, dict) else 0,
            "resale_count": len(resale),
        }
